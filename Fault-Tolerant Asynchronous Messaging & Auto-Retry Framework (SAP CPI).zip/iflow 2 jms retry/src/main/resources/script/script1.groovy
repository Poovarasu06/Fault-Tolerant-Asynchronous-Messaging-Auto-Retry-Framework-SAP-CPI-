
import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {

    def ex = message.getProperty("CamelExceptionCaught")
    String details = ""
    def current = ex
    int depth = 0

    while (current != null && depth < 10) {
        details += current.getClass().getName() + ": "
        details += (current.getMessage() ?: "") + " | "
        current = current.getCause()
        depth++
    }

    String lower = details.toLowerCase()

    // Extract a status code only if it appears in the exception text.
    def matcher = (details =~ /(?<!\d)(400|401|403|404|408|429|500|502|503|504)(?!\d)/)
    String errorCode = matcher.find() ? matcher.group(1) : "UNKNOWN"

    boolean permanent = false

    if (errorCode in ["400", "401", "403", "404"]) {
        permanent = true
    } else if (
        lower.contains("saxparseexception") ||
        lower.contains("mappingexception") ||
        lower.contains("jsonparseexception") ||
        lower.contains("invalid xml")
    ) {
        permanent = true
    }

    message.setProperty("ErrorCode", errorCode)
    message.setProperty("ErrorDetails", details)
    message.setProperty("ErrorType",
        permanent ? "PERMANENT" : "RETRYABLE")
    message.setProperty("RetryExceptionValid",
        permanent ? "false" : "true")

    return message
}
